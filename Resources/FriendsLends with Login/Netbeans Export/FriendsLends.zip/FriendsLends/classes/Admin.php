<?php

class Admin extends User{
    
}

