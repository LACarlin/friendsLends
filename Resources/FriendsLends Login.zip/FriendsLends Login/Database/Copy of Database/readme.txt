Netbeans expects the database to be called FriendsLends.  If you call the database something other than FriendsLends, amend the database name in the Netbeans project's config.php

Most of the user's passwords are set to 'test', apart from...
alexb = abtest
amritab = abtest
sandyf = sftest 

If you register a new user, the group id defaults to '9999'