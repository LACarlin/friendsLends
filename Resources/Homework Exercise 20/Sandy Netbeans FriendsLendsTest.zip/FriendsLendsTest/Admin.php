<?php

class Admin extends User{
    public function WhoAreYou(){
        echo "I am " .$this->FirstName . ". I am an Administrator. I AM ALL POWERFUL...MWAH HA HA HA";
    }

    

}

