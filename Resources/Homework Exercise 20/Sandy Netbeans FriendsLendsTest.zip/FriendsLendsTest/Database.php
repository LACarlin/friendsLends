<?php

class Database {
    //put your code here
}
