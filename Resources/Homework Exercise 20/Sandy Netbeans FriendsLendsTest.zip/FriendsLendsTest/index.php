<?php

include "User.php";
include "Admin.php";
include "Address.php";
include "Item.php";
//include "Database.php";

$user1 = new User('amritab', 'Amrita', 'Bains','');
$item1 = new Item('', 'Hobbies', 'Skateboard', 'Powell Peralta Ripper, Complete, Red/Blue, 7.5inch', '', '','My House', 'sandyf', '','active', '', '');
$item2 = new Item('', 'Hobbies', 'Pogo Stick', 'Krunk Pogo Stick - Black/Red', '', '','My House', 'sandyf', '','inactive', '', '');
$item3 = new Item('', 'Outdoors', 'Barbecue', 'Portable Barrel Barbecue', '', '','My House', 'sandyf', '','active', '2020-03-01', '2020-03-31');
$admin1 = new Admin('sandyf', 'Sandy', 'Forrester','');
$user1->welcome();
$item1->GetAvailableItems();
$item2->GetAvailableItems();
$item3->GetAvailableItems();
$admin1->WhoAreYou();

