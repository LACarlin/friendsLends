<?php

class User {
    private $CAusername;
    private $CAfirstname;
    private $CAsurname;
    private $CApw;
    
    public function __construct($CAusername, $CAfirstname, $CAsurname, $CApw){
        $this->Username = $CAusername;
        $this->FirstName = $CAfirstname;
        $this->Surname = $CAsurname;
        $this->PW = $CApw;
    }
    
    public function welcome(){
        echo "Welcome to FriendsLends, ". $this->FirstName .PHP_EOL;
    }
    
    public function GetFirstName(){
        return $this->FirstName .PHP_EOL;
    }
    
    
}
