<?php

class User {
    public $CAusername;
    public $CAfirstname;
    public $CAsurname;
    public $CApw;
    
    public function __construct($CAusername, $CAfirstname, $CAsurname, $CApw){
        $this->Username = $CAusername;
        $this->FirstName = $CAfirstname;
        $this->Surname = $CAsurname;
        $this->PW = $CApw;
    }
    
    function welcome(){
        echo "Welcome to FriendsLends, ". $this->FirstName .PHP_EOL;
    }
    
    function getname(){
        return $this->FirstName .PHP_EOL;
    }
}
