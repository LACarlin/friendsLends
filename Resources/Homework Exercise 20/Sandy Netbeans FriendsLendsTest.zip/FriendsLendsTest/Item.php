<?php

class Item {
    public $CAid;
    public $CAcategory;
    public $CAheadline;
    public $CAdescription;
    public $CAterms;
    public $CApicturelocation;
    public $CApickuplocation;
    public $CAowner;
    public $CAborrower;         /* default to null */
    public $CAactive_status;    /* default to inactive */
    public $CAstart_loan;       /* default to null */
    public $CAend_loan;         /* default to null */
    
    public function __construct($CAid, $CAcategory, $CAheadline, $CAdescription, $CAterms, $CApicturelocation, $CApickuplocation, $CAowner, $CAborrower, $CAactive_status, $CAstart_loan,$CAend_loan){
        $this->ID = $CAid;
        $this->Category = $CAcategory;
        $this->Headline = $CAheadline;
        $this->Description = $CAdescription;
        $this->Terms = $CAterms;
        $this->PictureLocation = $CApicturelocation;
        $this->PickupLocation = $CApickuplocation;
        $this->Owner = $CAowner;
        $this->Borrower = $CAborrower;
        $this->active_status = $CAactive_status;
        $this->start_loan = $CAstart_loan;
        $this->end_loan = $CAend_loan;
    }   
    
    function GetAvailableItems() {
        if ($this->start_loan == NULL && $this->active_status == 'active'){
            echo "The" . " $this->Headline" . " is available to loan" . PHP_EOL;
        } 
        elseif($this->active_status !== 'active'){
            echo "Sorry, the" . " $this->Headline" . " is currently unavailable" . PHP_EOL;
        } 
        elseif($this->start_loan !== NULL){
            echo "Sorry, the" . " $this->Headline" . " is already out on loan until" . " $this->end_loan" . PHP_EOL;
        }
    }
    
}

