<?php

class Address {
    private $CAaddrline1;
    private $CAaddrline2;
    private $CAcity;
    private $CApostcode;
    private $CAemail;
    private $CAcontactnumber;
    private $CAuser;
    
    public function __construct($CAaddrline1, $CAaddrline2, $CAcity, $CApostcode, $CAemail, $CAcontactnumber, $CAuser){
        $this->AddrLine1 = $CAaddrline1;
        $this->AddrLine2 = $CAaddrline2;
        $this->City = $CAcity;
        $this->Postcode = $CApostcode;
        $this->Email = $CAemail;
        $this->ContactNumber = $CAcontactnumber;
        $this->User = $CAuser;
    }
    
    public function GetPickupAddress(){
        echo "Items borrowed from " . "$this->User" . " can be collected from " . "$this->AddrLine1, $this->City, $this->Postcode." . PHP_EOL;
    }

}
