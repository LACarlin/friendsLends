<?php

class Address {
    public $CAaddrline1;
    public $CAaddrline2;
    public $CAcity;
    public $CApostcode;
    public $CAemail;
    public $CAcontactnumber;
    public $CAuser;
    
    public function __construct($CAaddrline1, $CAaddrline2, $CAcity, $CApostcode, $CAemail, $CAcontactnumber, $CAuser){
        $this->AddrLine1 = $CAaddrline1;
        $this->AddrLine2 = $CAaddrline2;
        $this->City = $CAcity;
        $this->Postcode = $CApostcode;
        $this->Email = $CAemail;
        $this->ContactNumber = $CAcontactnumber;
        $this->User = $CAuser;
    }

}
